package com.org.airport.exception;

public class RecordNotFoundException extends RuntimeException {
	public RecordNotFoundException(String s) {
		super(s);
	}

}
